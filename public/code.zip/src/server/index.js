const server = require('./server.js');

const config = require('./config.json');
const gameServer = new server(config);