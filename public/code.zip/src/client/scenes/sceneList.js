module.exports = [
    require('./login.js'),
    require('./world.js')
];